SET FORWARD 2026 - EVENT INFORMATION WEBSITE

Website concept
A one-page informational website for a proposed NU Fairview School of Engineering and Technology student event, SET Forward 2026, scheduled for December 2-4, 2026. Sample sessions, guests, times, and room assignments are identified as proposed or fictional pending confirmation.

Theme
An editorial event style inspired by the supplied reference: cream backgrounds, forest-green panels, blush accents, striped dividers, and serif display headings. The page uses the SET Forward 2026 logo and a Codability Tech student organization photo supplied for the project.

Files
- index.html: page content, navigation, schedule, clickable room map, and room-selection interaction
- styles.css: page styling and responsive layout
- images/: logo, student group photo, and fourth-floor schematic
- SETForward2026_Code_Explanation.pdf: plain-language guide to the website code

References
- WEB PROGRAMMING ASSIGNMENT 2.docx, supplied assignment brief
- NU Fairview official website: https://www.nu.edu.ph/nu-fairview/
- MDN Learn web development: https://developer.mozilla.org/en-US/docs/Learn
- Google Fonts: DM Sans and Playfair Display, https://fonts.google.com/
- Floor-plan arrangement and room numbers supplied by the student; diagram is schematic and not to scale

AI assistance disclosure
ChatGPT assisted with drafting and debugging the website.
